/*
 * This source file is part of an OSTIS project. For the latest info, see http://ostis.net
 * Distributed under the MIT License
 * (See accompanying file COPYING.MIT or copy at http://opensource.org/licenses/MIT)
 */

#ifndef _sc_iterator_h_
#define _sc_iterator_h_

#include "sc-core/sc_iterator3.h"
#include "sc-core/sc_iterator5.h"

#endif  // _sc_iterator_h_
